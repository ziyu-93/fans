$(document).ready(function() {
  var starIntro = {
    init: function() {
      tools.goback();
    }
  }
  starIntro.init();
})

let varietyDetail = {
  init() {
    tools.goback();
  }
}
varietyDetail.init();
